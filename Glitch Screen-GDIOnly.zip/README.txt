G̵̦͉͌̓͜l̸̘͓̒̀̚i̵͇̼͍͌͆͝t̵͖̦͉͛͛̕c̵̻͖̘͌̈́͘h̴̟̘͓͒̔̾ s̵̞̠̺̓̓͑ć̵̡͓̟͋̾r̴͎͎̺̾̕͘e̸̺̺̠͆͋e̴͕̞͊̒̿n̸̞̻͖̒̀̐.̸̪͚̈́͐̚͜e̴̦̺͓͌͛̕x̸͍͉͍̾̈́e̸̺̺͆͜͝
My new malware
You need .NET 4.8 (4.0)
Some elements from "Tera Bonus - Fixed Random" were used—specifically sounds and certain effects—along with a "bytebeat" from "Png.exe" by Kapi2.0peys.